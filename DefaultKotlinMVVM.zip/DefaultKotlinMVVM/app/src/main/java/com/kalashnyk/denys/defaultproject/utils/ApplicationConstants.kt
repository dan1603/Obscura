package com.kalashnyk.denys.defaultproject.utils

object ApplicationConstants {
    val CARD_DEFAULT = "default"
    val CARD_USER = "user"
    val CARD_FEED = "feed"
    val COLOR_PRIMARY_ALPHA = 255
}