package com.kalashnyk.denys.defaultproject.utils.extention

import android.content.Context

fun Context.dpToPx(dp: Int) = dp * resources.displayMetrics.density