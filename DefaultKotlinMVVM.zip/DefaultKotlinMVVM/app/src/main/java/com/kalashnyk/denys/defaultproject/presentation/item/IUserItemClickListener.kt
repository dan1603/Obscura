package com.kalashnyk.denys.defaultproject.presentation.item

interface IUserItemClickListener<M> {
    fun openDetail(m: M)
}