package com.kalashnyk.denys.defaultproject.utils.security

interface SkipSecureCheckActivity {
}